package com.cdac.training.productrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRestapiApplication.class, args);
	}

}
